import { HotlinkImage, ProjectStep, TechSkill } from '../types';

export const DEFAULT_HERO_IMAGE: HotlinkImage = {
  id: 'byan-main-graffiti',
  title: 'Muhammad Byan Pradika - Original Photo',
  url: 'https://images.unsplash.com/photo-1542204165-65bf26472b9b?auto=format&fit=crop&w=1200&q=80',
  alt: 'Muhammad Byan Pradika standing in front of graffiti in a nature park',
  category: 'Personal Portfolio',
  author: 'Muhammad Byan Pradika',
  description: 'Proyek pertama Muhammad Byan Pradika dengan latar belakang seni grafiti dan alam.'
};

export const HOTLINK_PRESETS: HotlinkImage[] = [
  DEFAULT_HERO_IMAGE,
  {
    id: 'nature-graffiti-art',
    title: 'Urban Graffiti & Nature Explorer',
    url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1200&q=80',
    alt: 'Urban graffiti style art banner',
    category: 'Creative Art',
    author: 'Unsplash Artist',
    description: 'Seni grafiti kontemporer yang merepresentasikan kreativitas tanpa batas.'
  },
  {
    id: 'developer-workspace',
    title: 'Developer Dark Setup',
    url: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1200&q=80',
    alt: 'Dark mode code editor screen with neon lighting',
    category: 'Web Development',
    author: 'Tech Gallery',
    description: 'Ruang kerja pengembang web modern dengan tampilan dark mode.'
  },
  {
    id: 'minimalist-abstract-tech',
    title: 'Kinetic Dark Mesh',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    alt: 'Abstract dark purple dynamic background',
    category: 'Abstract Design',
    author: '3D Render Studio',
    description: 'Desain abstrak kinetik dengan aksen warna ungu elektrik.'
  }
];

export const PROJECT_STEPS: ProjectStep[] = [
  {
    id: 'step-01',
    stepNumber: 'STEP 01',
    title: 'Perkenalan & Fondasi Utama',
    content: 'Halo, saya Muhammad Byan Pradika. Website ini adalah proyek pertama yang saya buat sebagai bagian dari proses belajar web development. Saya berharap proyek ini menjadi langkah awal untuk terus mengembangkan kemampuan saya dalam dunia pemrograman.',
    iconName: 'Code',
    tags: ['HTML5', 'CSS3', 'JavaScript', 'Dasar Web']
  },
  {
    id: 'step-02',
    stepNumber: 'STEP 02',
    title: 'Eksplorasi & Pengembangan',
    content: 'Website ini merupakan karya pertama saya dalam mempelajari pengembangan web dan menjadi awal dari perjalanan saya untuk terus berkembang sebagai developer.',
    iconName: 'Cpu',
    tags: ['React 19', 'Tailwind CSS', 'Hotlink HTML', 'Responsive Design']
  }
];

export const TECH_SKILLS: TechSkill[] = [
  { name: 'HTML5 Image Hotlinking', level: 95, category: 'frontend' },
  { name: 'Tailwind CSS Styling', level: 90, category: 'styling' },
  { name: 'React Component Architecture', level: 85, category: 'frontend' },
  { name: 'Responsive Web Design', level: 92, category: 'styling' },
  { name: 'Vite & Modern Build Tools', level: 88, category: 'tools' }
];
