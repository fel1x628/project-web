import React, { useState } from 'react';
import { X, Check, Copy, Code, Layers, Terminal, Sparkles, BookOpen, ExternalLink } from 'lucide-react';
import { TECH_SKILLS } from '../data/initialData';

interface DeepDiveModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DeepDiveModal: React.FC<DeepDiveModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'architecture' | 'hotlink-guide' | 'stack'>('architecture');
  const [copiedCode, setCopiedCode] = useState(false);

  if (!isOpen) return null;

  const sampleHtmlCode = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Muhammad Byan Pradika - First Project</title>
  <style>
    body { background-color: #0c0c0e; color: #fff; font-family: sans-serif; }
    .hero-img { border-radius: 16px; max-width: 100%; box-shadow: 0 0 30px rgba(168,85,247,0.3); }
  </style>
</head>
<body>
  <h1>Byan First Project</h1>
  <!-- Hotlink Gambar HTML dari Server Eksternal -->
  <img 
    src="https://images.unsplash.com/photo-1542204165-65bf26472b9b?auto=format&fit=crop&w=1200&q=80" 
    alt="Muhammad Byan Pradika - Nature & Graffiti" 
    class="hero-img" 
  />
</body>
</html>`;

  const copySampleCode = () => {
    navigator.clipboard.writeText(sampleHtmlCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl rounded-3xl bg-[#131315] border border-white/10 shadow-2xl overflow-hidden my-8">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-white/10 px-6 py-4 bg-zinc-950/80">
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-600/20 border border-purple-500/30 text-purple-300">
              <Sparkles className="h-5 w-5" />
            </span>
            <div>
              <h3 className="font-display text-lg font-bold text-white">
                Project Deep Dive & Architecture
              </h3>
              <p className="text-xs text-zinc-400 font-mono">
                Muhammad Byan Pradika — v1.0 Web
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="rounded-xl p-2 text-zinc-400 hover:bg-zinc-800 hover:text-white transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex border-b border-white/10 bg-zinc-900/50 px-6 text-xs font-mono">
          <button
            onClick={() => setActiveTab('architecture')}
            className={`py-3 px-4 border-b-2 font-medium transition ${
              activeTab === 'architecture'
                ? 'border-purple-500 text-purple-300'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Sistem Arsitektur
          </button>
          <button
            onClick={() => setActiveTab('hotlink-guide')}
            className={`py-3 px-4 border-b-2 font-medium transition ${
              activeTab === 'hotlink-guide'
                ? 'border-purple-500 text-purple-300'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Panduan Hotlink HTML
          </button>
          <button
            onClick={() => setActiveTab('stack')}
            className={`py-3 px-4 border-b-2 font-medium transition ${
              activeTab === 'stack'
                ? 'border-purple-500 text-purple-300'
                : 'border-transparent text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Teknologi Stack
          </button>
        </div>

        {/* Modal Body Content */}
        <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
          
          {/* Tab 1: Architecture */}
          {activeTab === 'architecture' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-sm text-purple-200">
                <p className="font-semibold text-purple-300 mb-1">
                  Tentang Proyek Byan First Project
                </p>
                <p className="text-xs leading-relaxed text-zinc-300">
                  Aplikasi web ini dibangun menggunakan pendekatan <strong>Kinetic Precision</strong> dark mode dengan kombinasi Glassmorphism, Tailwind CSS v4, React 19, dan Vite. Proyek ini memvisualisasikan perjalanan belajar web development Muhammad Byan Pradika.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-zinc-900 border border-white/5 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-mono text-cyan-400">
                    <Terminal className="h-4 w-4" />
                    <span>Rendering Engine</span>
                  </div>
                  <p className="text-sm font-semibold text-white">Vite & React 19 SPA</p>
                  <p className="text-xs text-zinc-400">
                    Proses kompilasi instan dengan pemuatan modul yang cepat dan responsif.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-zinc-900 border border-white/5 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-mono text-purple-400">
                    <Code className="h-4 w-4" />
                    <span>Media Hotlink Layer</span>
                  </div>
                  <p className="text-sm font-semibold text-white">Direct HTML Image Hotlink</p>
                  <p className="text-xs text-zinc-400">
                    Integrasi gambar langsung dari URL eksternal dengan pengujian status real-time.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Hotlink Guide */}
          {activeTab === 'hotlink-guide' && (
            <div className="space-y-4 font-sans text-sm">
              <p className="text-zinc-300 leading-relaxed text-xs sm:text-sm">
                <strong>Hotlinking</strong> adalah metode menampilkan media (gambar/video) pada halaman web Anda dengan merujuk langsung ke URL file di server eksternal, bukan mengunggah file tersebut ke hosting lokal Anda.
              </p>

              <div className="relative">
                <div className="flex items-center justify-between bg-zinc-950 px-4 py-2 rounded-t-xl border border-white/10 text-xs font-mono text-zinc-400">
                  <span>index.html</span>
                  <button
                    onClick={copySampleCode}
                    className="flex items-center gap-1 text-purple-400 hover:text-purple-300"
                  >
                    {copiedCode ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                    <span>{copiedCode ? 'Tersalin' : 'Salin Kode'}</span>
                  </button>
                </div>
                <pre className="bg-black p-4 rounded-b-xl border-x border-b border-white/10 font-mono text-xs text-purple-200 overflow-x-auto select-all">
                  <code>{sampleHtmlCode}</code>
                </pre>
              </div>
            </div>
          )}

          {/* Tab 3: Tech Stack */}
          {activeTab === 'stack' && (
            <div className="space-y-4">
              <p className="text-xs text-zinc-400">
                Kemampuan dan teknologi yang digunakan dalam proyek pertama ini:
              </p>
              <div className="space-y-3">
                {TECH_SKILLS.map((skill, index) => (
                  <div key={index} className="space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-zinc-200">{skill.name}</span>
                      <span className="text-purple-400">{skill.level}%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-zinc-900 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-purple-600 to-indigo-500 transition-all duration-1000"
                        style={{ width: `${skill.level}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between border-t border-white/10 px-6 py-4 bg-zinc-950/80">
          <span className="text-xs font-mono text-zinc-500">
            © 2024 Muhammad Byan Pradika
          </span>
          <button
            onClick={onClose}
            className="rounded-xl bg-purple-600 hover:bg-purple-500 px-5 py-2 text-xs font-semibold text-white transition shadow-lg shadow-purple-600/30"
          >
            Tutup Deep Dive
          </button>
        </div>

      </div>
    </div>
  );
};
