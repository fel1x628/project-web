import React, { useState } from 'react';
import { PROJECT_STEPS } from '../data/initialData';
import { Network, Code, CheckCircle2, ArrowRight, Sparkles } from 'lucide-react';

export const StepCards: React.FC = () => {
  const [activeCard, setActiveCard] = useState<string | null>(null);

  return (
    <section id="features" className="py-12 sm:py-16 mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
        
        {/* Card 1: Halo, saya Muhammad Byan Pradika... */}
        <div 
          onMouseEnter={() => setActiveCard('card-1')}
          onMouseLeave={() => setActiveCard(null)}
          className="group relative overflow-hidden rounded-2xl bg-[#18181b]/70 border border-white/10 p-6 sm:p-8 transition-all duration-300 hover:border-purple-500/40 hover:bg-[#1f1e24] hover:shadow-2xl hover:shadow-purple-500/10"
        >
          {/* Background Abstract Graphic Bracket `{}` matching screenshot */}
          <div className="pointer-events-none absolute right-4 top-4 text-white/5 font-mono text-8xl font-black select-none transition group-hover:text-purple-500/10">
            {`{}`}
          </div>

          {/* Icon Box */}
          <div className="relative mb-6 flex h-11 w-11 items-center justify-center rounded-xl bg-zinc-900 border border-zinc-700/60 text-white shadow-md group-hover:border-purple-500/50 group-hover:bg-purple-600/20 group-hover:text-purple-300 transition">
            <Network className="h-5 w-5" />
          </div>

          {/* Main Indonesian Text from Screenshot */}
          <p className="relative text-sm sm:text-base leading-relaxed text-zinc-300 font-normal">
            Halo, saya <strong className="font-semibold text-white">Muhammad Byan Pradika</strong>. Website ini adalah proyek pertama yang saya buat sebagai bagian dari proses belajar web development. Saya berharap proyek ini menjadi langkah awal untuk terus mengembangkan kemampuan saya dalam dunia pemrograman.
          </p>

          {/* Interactive Skill Tags Footer */}
          <div className="mt-6 pt-4 border-t border-white/5 flex flex-wrap items-center gap-2">
            {PROJECT_STEPS[0].tags.map((tag, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1 rounded-md bg-zinc-900/90 border border-white/5 px-2.5 py-1 text-[11px] font-mono text-zinc-400 group-hover:text-purple-300 group-hover:border-purple-500/20 transition"
              >
                <CheckCircle2 className="h-3 w-3 text-purple-400" />
                <span>{tag}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Card 2: — STEP 02 */}
        <div 
          onMouseEnter={() => setActiveCard('card-2')}
          onMouseLeave={() => setActiveCard(null)}
          className="group relative overflow-hidden rounded-2xl bg-[#18181b]/70 border border-white/10 p-6 sm:p-8 transition-all duration-300 hover:border-purple-500/40 hover:bg-[#1f1e24] hover:shadow-2xl hover:shadow-purple-500/10"
        >
          {/* Background Abstract Flow Diagram graphic matching screenshot */}
          <div className="pointer-events-none absolute right-4 top-4 text-white/5 select-none transition group-hover:text-purple-500/10">
            <svg className="h-28 w-28 opacity-40" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="10" y="10" width="25" height="25" rx="4" />
              <rect x="55" y="10" width="25" height="25" rx="4" />
              <rect x="55" y="55" width="25" height="25" rx="4" />
              <path d="M35 22.5 H55 M67.5 35 V55" />
            </svg>
          </div>

          {/* Step Badge */}
          <div className="mb-4 text-xs font-mono font-medium tracking-wider text-purple-400">
            — STEP 02
          </div>

          {/* Icon Box */}
          <div className="relative mb-6 flex h-11 w-11 items-center justify-center rounded-xl bg-zinc-900 border border-zinc-700/60 text-white shadow-md group-hover:border-purple-500/50 group-hover:bg-purple-600/20 group-hover:text-purple-300 transition">
            <Code className="h-5 w-5" />
          </div>

          {/* Main Indonesian Text from Screenshot */}
          <p className="relative text-sm sm:text-base leading-relaxed text-zinc-300 font-normal">
            Website ini merupakan karya pertama saya dalam mempelajari pengembangan web dan menjadi awal dari perjalanan saya untuk terus berkembang sebagai developer.
          </p>

          {/* Interactive Roadmap Tags Footer */}
          <div className="mt-6 pt-4 border-t border-white/5 flex flex-wrap items-center gap-2">
            {PROJECT_STEPS[1].tags.map((tag, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1 rounded-md bg-zinc-900/90 border border-white/5 px-2.5 py-1 text-[11px] font-mono text-zinc-400 group-hover:text-cyan-300 group-hover:border-cyan-500/20 transition"
              >
                <Sparkles className="h-3 w-3 text-cyan-400" />
                <span>{tag}</span>
              </span>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
