import React from 'react';

export const GreetingSection: React.FC = () => {
  return (
    <section className="py-12 sm:py-16 text-center border-t border-white/5 bg-[#0e0e10]/50">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        
        {/* Main Heading matching screenshot */}
        <h2 className="font-display text-4xl sm:text-5xl font-extrabold tracking-tight text-white mb-4">
          Hello Everyone
        </h2>

        {/* Subtitle matching exact text in user's screenshot */}
        <p className="mx-auto max-w-2xl text-base sm:text-lg text-zinc-400 font-normal leading-relaxed">
          To introduce everyone, I am Muhammad Byan Pradika and this is one of my first projects to create a website
        </p>

        {/* Decorative subtle accent line */}
        <div className="mt-8 flex justify-center">
          <div className="h-1 w-16 rounded-full bg-gradient-to-r from-purple-500 to-indigo-500 opacity-60" />
        </div>

      </div>
    </section>
  );
};
