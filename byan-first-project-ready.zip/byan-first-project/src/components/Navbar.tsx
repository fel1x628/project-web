import React, { useState } from 'react';
import { Menu, X, ArrowUpRight, Image as ImageIcon, Sparkles } from 'lucide-react';

interface NavbarProps {
  onOpenHotlinkTool: () => void;
  onOpenDeepDive: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenHotlinkTool, onOpenDeepDive }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-[#0c0c0e]/80 backdrop-blur-md transition-all">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8 py-3.5">
        {/* Brand Logo */}
        <div className="flex items-center gap-3">
          <a
            href="#"
            className="group flex items-center gap-2 text-xl font-bold tracking-tight text-white transition hover:opacity-90 font-display"
          >
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-tr from-purple-600 to-indigo-500 text-white shadow-md shadow-purple-500/20 font-mono text-sm">
              BP
            </span>
            <span className="text-white font-semibold group-hover:text-purple-300 transition">
              ByanPradika
            </span>
          </a>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-300">
          <button
            onClick={() => scrollToSection('platform')}
            className="transition hover:text-white hover:cursor-pointer"
          >
            Platform
          </button>
          <button
            onClick={() => scrollToSection('features')}
            className="transition hover:text-white hover:cursor-pointer"
          >
            Features
          </button>
          <button
            onClick={() => scrollToSection('hotlink-tool')}
            className="flex items-center gap-1.5 transition text-purple-400 hover:text-purple-300 hover:cursor-pointer font-mono text-xs bg-purple-500/10 px-2.5 py-1 rounded-full border border-purple-500/20"
          >
            <ImageIcon className="h-3.5 w-3.5" />
            <span>Hotlink HTML</span>
          </button>
          <button
            onClick={() => scrollToSection('solutions')}
            className="transition hover:text-white hover:cursor-pointer"
          >
            Solutions
          </button>
          <button
            onClick={() => scrollToSection('pricing')}
            className="transition hover:text-white hover:cursor-pointer"
          >
            Pricing
          </button>
        </nav>

        {/* Right CTA Button */}
        <div className="hidden md:flex items-center gap-3">
          <button
            onClick={onOpenHotlinkTool}
            className="flex items-center gap-2 rounded-lg bg-zinc-900 border border-zinc-700/60 px-3.5 py-1.5 text-xs font-mono font-medium text-zinc-200 transition hover:bg-zinc-800 hover:border-zinc-500 hover:text-white hover:cursor-pointer"
          >
            <Sparkles className="h-3.5 w-3.5 text-purple-400" />
            <span>Uji Hotlink</span>
          </button>

          <button
            onClick={onOpenDeepDive}
            className="flex items-center gap-2 rounded-lg border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-medium text-white transition hover:border-purple-500/50 hover:bg-purple-600/20 hover:cursor-pointer"
          >
            <span>Get Started</span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </button>
        </div>

        {/* Mobile Hamburger Button */}
        <div className="flex md:hidden">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="rounded-lg p-2 text-zinc-400 transition hover:bg-zinc-800 hover:text-white"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Dropdown Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-white/10 bg-[#131315] px-4 pt-3 pb-6 space-y-3">
          <button
            onClick={() => scrollToSection('platform')}
            className="block w-full text-left py-2 text-sm font-medium text-zinc-300 hover:text-white"
          >
            Platform
          </button>
          <button
            onClick={() => scrollToSection('features')}
            className="block w-full text-left py-2 text-sm font-medium text-zinc-300 hover:text-white"
          >
            Features
          </button>
          <button
            onClick={() => scrollToSection('hotlink-tool')}
            className="flex items-center gap-2 py-2 text-sm font-medium text-purple-400 hover:text-purple-300"
          >
            <ImageIcon className="h-4 w-4" />
            <span>Hotlink HTML Tool</span>
          </button>
          <button
            onClick={() => scrollToSection('solutions')}
            className="block w-full text-left py-2 text-sm font-medium text-zinc-300 hover:text-white"
          >
            Solutions
          </button>
          <button
            onClick={() => scrollToSection('pricing')}
            className="block w-full text-left py-2 text-sm font-medium text-zinc-300 hover:text-white"
          >
            Pricing
          </button>
          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenHotlinkTool();
              }}
              className="w-full text-center rounded-lg bg-purple-600 py-2 text-sm font-medium text-white shadow-lg shadow-purple-600/30"
            >
              Uji Gambar Hotlink
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenDeepDive();
              }}
              className="w-full text-center rounded-lg border border-white/10 bg-zinc-800 py-2 text-sm font-medium text-zinc-200"
            >
              View Deep Dive
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
