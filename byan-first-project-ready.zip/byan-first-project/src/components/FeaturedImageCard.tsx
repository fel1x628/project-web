import React, { useState } from 'react';
import { HotlinkImage } from '../types';
import { Copy, Check, Code2, Link as LinkIcon, ExternalLink, Image as ImageIcon, Sliders } from 'lucide-react';

interface FeaturedImageCardProps {
  currentImage: HotlinkImage;
  onOpenHotlinkTool: () => void;
}

export const FeaturedImageCard: React.FC<FeaturedImageCardProps> = ({
  currentImage,
  onOpenHotlinkTool
}) => {
  const [copied, setCopied] = useState(false);
  const [imgLoaded, setImgLoaded] = useState(true);
  const [showHtmlCode, setShowHtmlCode] = useState(false);

  // Generate clean standard HTML hotlink code
  const htmlSnippet = `<img src="${currentImage.url}" alt="${currentImage.alt}" width="100%" style="border-radius: 12px; max-width: 100%; height: auto;" />`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(htmlSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section className="relative mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 my-8">
      {/* Outer Glow Container */}
      <div className="relative group rounded-3xl p-1.5 bg-gradient-to-b from-white/10 via-white/5 to-purple-500/10 border border-white/10 shadow-2xl backdrop-blur-xl">
        
        {/* Top Toolbar overlay on image card */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 bg-zinc-950/80 rounded-t-2xl border-b border-white/5 text-xs text-zinc-400 font-mono">
          <div className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-zinc-300 font-medium">HTML Hotlink Status: Live</span>
            <span className="hidden sm:inline text-zinc-600">|</span>
            <span className="hidden sm:inline text-zinc-500 truncate max-w-[280px]">
              {currentImage.url}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowHtmlCode(!showHtmlCode)}
              className="flex items-center gap-1.5 rounded-md bg-zinc-800/80 px-2.5 py-1 text-zinc-300 hover:text-white hover:bg-zinc-700 transition"
              title="Toggle HTML Code View"
            >
              <Code2 className="h-3.5 w-3.5 text-purple-400" />
              <span>{showHtmlCode ? 'Tutup HTML' : 'Lihat HTML'}</span>
            </button>

            <button
              onClick={copyToClipboard}
              className="flex items-center gap-1.5 rounded-md bg-purple-600/30 border border-purple-500/30 px-2.5 py-1 text-purple-300 hover:bg-purple-600 hover:text-white transition"
              title="Salin Kode HTML Hotlink"
            >
              {copied ? (
                <>
                  <Check className="h-3.5 w-3.5 text-emerald-400" />
                  <span className="text-emerald-300">Tersalin!</span>
                </>
              ) : (
                <>
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy Hotlink</span>
                </>
              )}
            </button>

            <button
              onClick={onOpenHotlinkTool}
              className="flex items-center gap-1.5 rounded-md bg-zinc-800 border border-zinc-700 px-2.5 py-1 text-zinc-200 hover:bg-zinc-700 hover:text-white transition"
              title="Ubah URL Gambar"
            >
              <Sliders className="h-3.5 w-3.5 text-cyan-400" />
              <span className="hidden sm:inline">Kelola Gambar</span>
            </button>
          </div>
        </div>

        {/* Code Snippet Drawer when active */}
        {showHtmlCode && (
          <div className="bg-zinc-950 p-4 border-b border-white/10 font-mono text-xs text-purple-300 overflow-x-auto">
            <div className="flex items-center justify-between mb-2 text-zinc-500">
              <span>{/* Kode HTML Hotlink Siap Pakai */}</span>
              <span className="text-[10px] text-zinc-400">Salin & Tempel di File HTML Anda</span>
            </div>
            <pre className="bg-black/80 p-3 rounded-lg border border-purple-500/20 text-zinc-200 select-all">
              <code>{htmlSnippet}</code>
            </pre>
          </div>
        )}

        {/* Main Hotlink Image Display Container matching Screenshot */}
        <div className="relative overflow-hidden rounded-b-2xl bg-zinc-950 aspect-[16/9] sm:aspect-[21/9] flex items-center justify-center">
          <img
            src={currentImage.url}
            alt={currentImage.alt}
            onLoad={() => setImgLoaded(true)}
            onError={() => setImgLoaded(false)}
            className="h-full w-full object-cover object-center transition-transform duration-700 group-hover:scale-[1.01]"
          />

          {/* Dark Gradient Overlay for cinematic feel matching mockup */}
          <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-transparent to-black/30 pointer-events-none" />

          {/* Image Fallback Warning if link breaks */}
          {!imgLoaded && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-900 text-zinc-400 p-6 text-center">
              <ImageIcon className="h-12 w-12 text-zinc-600 mb-3" />
              <p className="font-semibold text-zinc-300">Gagal memuat gambar dari URL Hotlink</p>
              <p className="text-xs text-zinc-500 mt-1 max-w-md">
                Pastikan URL gambar valid dan mengizinkan cross-origin embedding.
              </p>
              <button
                onClick={onOpenHotlinkTool}
                className="mt-4 rounded-lg bg-purple-600 px-4 py-2 text-xs font-medium text-white"
              >
                Ganti URL Hotlink
              </button>
            </div>
          )}

          {/* Bottom Caption Overlay */}
          <div className="absolute bottom-4 left-4 right-4 flex flex-wrap items-end justify-between gap-2 pointer-events-none">
            <div className="bg-black/60 backdrop-blur-md px-3.5 py-2 rounded-xl border border-white/10 max-w-md">
              <p className="text-xs font-medium text-white font-display">
                {currentImage.title}
              </p>
              <p className="text-[11px] text-zinc-400 mt-0.5 line-clamp-1">
                {currentImage.description}
              </p>
            </div>

            <a
              href={currentImage.url}
              target="_blank"
              rel="noopener noreferrer"
              className="pointer-events-auto inline-flex items-center gap-1.5 bg-black/70 hover:bg-black text-xs font-mono text-zinc-300 hover:text-white px-3 py-1.5 rounded-lg border border-white/10 transition"
            >
              <ExternalLink className="h-3 w-3" />
              <span>Buka Gambar Direct</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};
