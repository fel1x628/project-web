import React from 'react';
import { Play, Rocket, Sparkles } from 'lucide-react';

interface HeroProps {
  onLaunchApp: () => void;
  onOpenDeepDive: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onLaunchApp, onOpenDeepDive }) => {
  return (
    <section className="relative pt-12 pb-8 sm:pt-16 sm:pb-12 text-center overflow-hidden">
      {/* Background ambient lighting glow */}
      <div className="pointer-events-none absolute left-1/2 top-0 -translate-x-1/2 -translate-y-1/2 h-[350px] w-[600px] rounded-full bg-purple-600/15 blur-[120px]" />
      
      <div className="relative mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        {/* Version Badge */}
        <div className="inline-flex items-center gap-2 rounded-full border border-purple-500/30 bg-purple-500/10 px-4 py-1.5 text-xs font-mono text-purple-300 shadow-sm backdrop-blur-md mb-8 hover:border-purple-500/60 transition cursor-pointer"
             onClick={onOpenDeepDive}>
          <span className="h-1.5 w-1.5 rounded-full bg-purple-400 animate-pulse" />
          <span>v1.0 web Muhammad Byan Pradika</span>
        </div>

        {/* Hero Title */}
        <h1 className="font-display text-5xl sm:text-6xl md:text-7xl font-extrabold tracking-tight text-white mb-6 leading-[1.1]">
          Muhammad <br className="hidden sm:inline" />
          <span className="bg-gradient-to-r from-white via-zinc-100 to-purple-300 bg-clip-text text-transparent">
            Byan Pradika
          </span>
        </h1>

        {/* Brief Subtitle / Tagline */}
        <p className="mx-auto max-w-2xl text-base sm:text-lg text-zinc-400 mb-10 leading-relaxed font-normal">
          Proyek web pertama yang dirancang dengan antarmuka presisi kinetik dark-mode, 
          dukungan <strong className="text-zinc-200 font-semibold">hotlinking gambar dari HTML</strong>, dan arsitektur web modern.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onLaunchApp}
            className="group relative inline-flex items-center justify-center gap-2 rounded-xl bg-purple-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-purple-600/30 transition-all hover:bg-purple-500 hover:shadow-purple-500/40 hover:-translate-y-0.5 active:translate-y-0 hover:cursor-pointer w-full sm:w-auto"
          >
            <Rocket className="h-4 w-4 transition group-hover:rotate-12" />
            <span>Launch App</span>
          </button>

          <button
            onClick={onOpenDeepDive}
            className="group inline-flex items-center justify-center gap-2.5 rounded-xl border border-white/10 bg-zinc-900/80 px-6 py-3 text-sm font-medium text-zinc-200 transition-all hover:bg-zinc-800 hover:border-white/20 hover:text-white hover:-translate-y-0.5 active:translate-y-0 hover:cursor-pointer w-full sm:w-auto"
          >
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-white/10 text-white transition group-hover:bg-purple-500 group-hover:text-white">
              <Play className="h-3 w-3 fill-current ml-0.5" />
            </span>
            <span>View the deep dive</span>
          </button>
        </div>
      </div>
    </section>
  );
};
