import React, { useState } from 'react';
import { HotlinkImage } from '../types';
import { HOTLINK_PRESETS } from '../data/initialData';
import {
  Link as LinkIcon,
  Check,
  Copy,
  Image as ImageIcon,
  Sparkles,
  Code2,
  RefreshCw,
  Info,
  Layers,
  Wand2
} from 'lucide-react';

interface HotlinkToolProps {
  currentImage: HotlinkImage;
  onSelectImage: (image: HotlinkImage) => void;
}

export const HotlinkTool: React.FC<HotlinkToolProps> = ({
  currentImage,
  onSelectImage
}) => {
  const [inputUrl, setInputUrl] = useState(currentImage.url);
  const [altText, setAltText] = useState(currentImage.alt);
  const [titleText, setTitleText] = useState(currentImage.title);
  const [borderRadius, setBorderRadius] = useState('12px');
  const [copiedFormat, setCopiedFormat] = useState<string | null>(null);
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');

  const handleApplyCustomUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputUrl.trim()) return;

    setTestStatus('testing');

    // Create temporary image test
    const img = new Image();
    img.src = inputUrl;
    img.onload = () => {
      setTestStatus('success');
      onSelectImage({
        id: `custom-${Date.now()}`,
        title: titleText || 'Kustom Hotlink Gambar',
        url: inputUrl,
        alt: altText || 'Gambar Hotlink HTML',
        category: 'Kustom User',
        description: 'Gambar hasil hotlink URL kustom pilihan Anda.'
      });
    };
    img.onerror = () => {
      setTestStatus('error');
    };
  };

  // Generate HTML Hotlink Snippet
  const htmlCode = `<img src="${inputUrl}" alt="${altText}" style="border-radius: ${borderRadius}; max-width: 100%; height: auto;" />`;

  // Generate React JSX Snippet
  const jsxCode = `<img\n  src="${inputUrl}"\n  alt="${altText}"\n  className="w-full h-auto rounded-[${borderRadius}] object-cover"\n/>`;

  // Generate Markdown Snippet
  const markdownCode = `![${altText}](${inputUrl})`;

  // Generate CSS Snippet
  const cssCode = `.hero-banner {\n  background-image: url('${inputUrl}');\n  background-size: cover;\n  background-position: center;\n}`;

  const copyCode = (text: string, formatName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedFormat(formatName);
    setTimeout(() => setCopiedFormat(null), 2000);
  };

  return (
    <section id="hotlink-tool" className="py-12 bg-zinc-950/60 border-y border-white/5 my-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Header Title */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 rounded-full bg-purple-500/10 border border-purple-500/20 px-3.5 py-1 text-xs font-mono text-purple-300 mb-3">
            <Wand2 className="h-3.5 w-3.5 text-purple-400" />
            <span>Generator & Penguji Hotlink Gambar HTML</span>
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-white tracking-tight">
            Fitur Hotlink Gambar dari HTML
          </h2>
          <p className="mt-3 text-sm sm:text-base text-zinc-400">
            Anda dapat langsung memasukkan URL gambar eksternal (hotlinking) ke dalam kode HTML untuk menampilkan gambar secara dinamis tanpa perlu menyimpan file di server lokal.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Form & Presets */}
          <div className="lg:col-span-7 space-y-6">
            
            {/* Custom URL Input Box */}
            <div className="glass-panel p-6 rounded-2xl border border-white/10 shadow-xl">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2 font-display">
                <LinkIcon className="h-5 w-5 text-purple-400" />
                <span>Masukkan URL Gambar (Hotlink)</span>
              </h3>

              <form onSubmit={handleApplyCustomUrl} className="space-y-4">
                <div>
                  <label className="block text-xs font-mono text-zinc-400 mb-1.5">
                    URL Gambar Eksternal (Direct Image Link)
                  </label>
                  <div className="relative">
                    <input
                      type="url"
                      value={inputUrl}
                      onChange={(e) => {
                        setInputUrl(e.target.value);
                        setTestStatus('idle');
                      }}
                      placeholder="https://example.com/image.jpg"
                      required
                      className="w-full rounded-xl bg-zinc-900 border border-zinc-700 px-4 py-2.5 text-sm text-white placeholder-zinc-500 focus:border-purple-500 focus:outline-none focus:ring-1 focus:ring-purple-500 transition font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono text-zinc-400 mb-1.5">
                      Judul / Deskripsi Gambar
                    </label>
                    <input
                      type="text"
                      value={titleText}
                      onChange={(e) => setTitleText(e.target.value)}
                      placeholder="Muhammad Byan Pradika"
                      className="w-full rounded-xl bg-zinc-900 border border-zinc-700 px-3.5 py-2 text-sm text-white focus:border-purple-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono text-zinc-400 mb-1.5">
                      Teks Alt (HTML alt attribute)
                    </label>
                    <input
                      type="text"
                      value={altText}
                      onChange={(e) => setAltText(e.target.value)}
                      placeholder="Byan Pradika Photo"
                      className="w-full rounded-xl bg-zinc-900 border border-zinc-700 px-3.5 py-2 text-sm text-white focus:border-purple-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div className="flex items-center gap-2 text-xs font-mono">
                    {testStatus === 'testing' && (
                      <span className="text-amber-400 flex items-center gap-1">
                        <RefreshCw className="h-3.5 w-3.5 animate-spin" /> Menguji URL...
                      </span>
                    )}
                    {testStatus === 'success' && (
                      <span className="text-emerald-400 flex items-center gap-1">
                        <Check className="h-3.5 w-3.5" /> URL Gambar Berhasil Dimuat!
                      </span>
                    )}
                    {testStatus === 'error' && (
                      <span className="text-red-400 flex items-center gap-1">
                        ⚠️ Gagal memuat URL. Periksa koneksi atau URL link direct.
                      </span>
                    )}
                  </div>

                  <button
                    type="submit"
                    className="flex items-center gap-2 rounded-xl bg-purple-600 hover:bg-purple-500 px-5 py-2 text-xs font-semibold text-white shadow-lg shadow-purple-600/30 transition hover:cursor-pointer"
                  >
                    <Sparkles className="h-4 w-4" />
                    <span>Terapkan Hotlink</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Quick Presets */}
            <div className="glass-panel p-6 rounded-2xl border border-white/10">
              <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2 font-display">
                <Layers className="h-4 w-4 text-cyan-400" />
                <span>Pilih Galeri Preset Hotlink:</span>
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {HOTLINK_PRESETS.map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => {
                      setInputUrl(preset.url);
                      setAltText(preset.alt);
                      setTitleText(preset.title);
                      onSelectImage(preset);
                      setTestStatus('success');
                    }}
                    className={`group relative rounded-xl overflow-hidden border transition text-left ${
                      currentImage.url === preset.url
                        ? 'border-purple-500 ring-2 ring-purple-500/30'
                        : 'border-white/10 hover:border-white/30'
                    }`}
                  >
                    <div className="aspect-[4/3] bg-zinc-900 overflow-hidden">
                      <img
                        src={preset.url}
                        alt={preset.alt}
                        className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
                      />
                    </div>
                    <div className="p-2 bg-zinc-900/90 text-[11px]">
                      <p className="font-medium text-zinc-200 truncate">{preset.title}</p>
                      <p className="text-[10px] text-purple-400 truncate font-mono">{preset.category}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Right Column: Code Snippets & Preview */}
          <div className="lg:col-span-5 space-y-4">
            
            <div className="glass-panel p-6 rounded-2xl border border-white/10 shadow-xl">
              <div className="flex items-center justify-between mb-4 border-b border-white/10 pb-3">
                <div className="flex items-center gap-2">
                  <Code2 className="h-5 w-5 text-purple-400" />
                  <h3 className="text-base font-semibold text-white font-display">
                    Kode HTML Hotlink Generasi
                  </h3>
                </div>
                <span className="text-[10px] font-mono bg-zinc-800 text-zinc-300 px-2 py-0.5 rounded">
                  HTML5 Standard
                </span>
              </div>

              {/* HTML Snippet Box */}
              <div className="space-y-4 font-mono text-xs">
                
                {/* Format 1: HTML */}
                <div>
                  <div className="flex items-center justify-between mb-1 text-zinc-400">
                    <span>File .html / Website:</span>
                    <button
                      onClick={() => copyCode(htmlCode, 'html')}
                      className="text-purple-400 hover:text-purple-300 flex items-center gap-1"
                    >
                      {copiedFormat === 'html' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                      <span>{copiedFormat === 'html' ? 'Tersalin' : 'Copy HTML'}</span>
                    </button>
                  </div>
                  <pre className="bg-black p-3 rounded-xl border border-zinc-800 text-purple-200 overflow-x-auto whitespace-pre-wrap break-all select-all">
                    <code>{htmlCode}</code>
                  </pre>
                </div>

                {/* Format 2: React JSX */}
                <div>
                  <div className="flex items-center justify-between mb-1 text-zinc-400">
                    <span>React / JSX Component:</span>
                    <button
                      onClick={() => copyCode(jsxCode, 'jsx')}
                      className="text-purple-400 hover:text-purple-300 flex items-center gap-1"
                    >
                      {copiedFormat === 'jsx' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                      <span>{copiedFormat === 'jsx' ? 'Tersalin' : 'Copy JSX'}</span>
                    </button>
                  </div>
                  <pre className="bg-black p-3 rounded-xl border border-zinc-800 text-cyan-200 overflow-x-auto whitespace-pre-wrap break-all select-all">
                    <code>{jsxCode}</code>
                  </pre>
                </div>

                {/* Format 3: Markdown */}
                <div>
                  <div className="flex items-center justify-between mb-1 text-zinc-400">
                    <span>Markdown (GitHub / README):</span>
                    <button
                      onClick={() => copyCode(markdownCode, 'markdown')}
                      className="text-purple-400 hover:text-purple-300 flex items-center gap-1"
                    >
                      {copiedFormat === 'markdown' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                      <span>{copiedFormat === 'markdown' ? 'Tersalin' : 'Copy MD'}</span>
                    </button>
                  </div>
                  <pre className="bg-black p-3 rounded-xl border border-zinc-800 text-emerald-200 overflow-x-auto whitespace-pre-wrap break-all select-all">
                    <code>{markdownCode}</code>
                  </pre>
                </div>

              </div>

              {/* Explanation Note */}
              <div className="mt-5 p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-xs text-purple-200 flex items-start gap-2.5">
                <Info className="h-4 w-4 text-purple-400 shrink-0 mt-0.5" />
                <p>
                  <strong>Tips Hotlink HTML:</strong> Menautkan gambar secara langsung menggunakan atribut <code className="text-white bg-black/50 px-1 rounded">src="URL"</code> memisahkan penyimpanan media dari logika kode, mempecepat proses deployment web Anda!
                </p>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
