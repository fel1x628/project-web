import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="mt-20 border-t border-white/10 bg-[#0c0c0e] text-zinc-400 font-sans">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-12">
          
          {/* Brand & Mission */}
          <div className="md:col-span-5 space-y-4">
            <a href="#" className="flex items-center gap-2 text-2xl font-bold tracking-tight text-white font-display">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-600 text-white font-mono text-sm">
                BP
              </span>
              <span>ByanPradika</span>
            </a>
            <p className="text-sm text-zinc-400 max-w-sm font-normal leading-relaxed">
              Next-generation automation for high-velocity teams.
            </p>
          </div>

          {/* Links Column 1: Product */}
          <div className="md:col-span-2 space-y-3">
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider font-mono">
              Product
            </h4>
            <ul className="space-y-2.5 text-sm font-normal">
              <li><a href="#platform" className="hover:text-white transition">Platform</a></li>
              <li><a href="#features" className="hover:text-white transition">Features</a></li>
              <li><a href="#pricing" className="hover:text-white transition">Pricing</a></li>
            </ul>
          </div>

          {/* Links Column 2: Company */}
          <div className="md:col-span-2 space-y-3">
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider font-mono">
              Company
            </h4>
            <ul className="space-y-2.5 text-sm font-normal">
              <li><a href="#about" className="hover:text-white transition">About</a></li>
              <li><a href="#careers" className="hover:text-white transition">Careers</a></li>
              <li><a href="#blog" className="hover:text-white transition">Blog</a></li>
            </ul>
          </div>

          {/* Links Column 3: Legal */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider font-mono">
              Legal
            </h4>
            <ul className="space-y-2.5 text-sm font-normal">
              <li><a href="#privacy" className="hover:text-white transition">Privacy</a></li>
              <li><a href="#terms" className="hover:text-white transition">Terms</a></li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar matching screenshot */}
        <div className="mt-12 pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-zinc-500">
          <p>© 2024 ByanPradika. All rights reserved.</p>
          
          <div className="flex items-center gap-6">
            <a href="https://twitter.com" target="_blank" rel="noreferrer" className="hover:text-zinc-300 transition">
              Twitter
            </a>
            <a href="https://github.com" target="_blank" rel="noreferrer" className="hover:text-zinc-300 transition">
              GitHub
            </a>
            <a href="https://discord.com" target="_blank" rel="noreferrer" className="hover:text-zinc-300 transition">
              Discord
            </a>
          </div>
        </div>

      </div>
    </footer>
  );
};
