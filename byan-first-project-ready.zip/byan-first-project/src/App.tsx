import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { FeaturedImageCard } from './components/FeaturedImageCard';
import { HotlinkTool } from './components/HotlinkTool';
import { GreetingSection } from './components/GreetingSection';
import { StepCards } from './components/StepCards';
import { DeepDiveModal } from './components/DeepDiveModal';
import { Footer } from './components/Footer';
import { DEFAULT_HERO_IMAGE } from './data/initialData';
import { HotlinkImage } from './types';

export default function App() {
  const [currentImage, setCurrentImage] = useState<HotlinkImage>(DEFAULT_HERO_IMAGE);
  const [isDeepDiveOpen, setIsDeepDiveOpen] = useState(false);

  const handleLaunchApp = () => {
    const hotlinkSection = document.getElementById('hotlink-tool');
    if (hotlinkSection) {
      hotlinkSection.scrollIntoView({ behavior: 'smooth' });
    } else {
      setIsDeepDiveOpen(true);
    }
  };

  const scrollToHotlinkTool = () => {
    const el = document.getElementById('hotlink-tool');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0c0c0e] text-[#e5e1e4] selection:bg-purple-500 selection:text-white font-sans antialiased">
      {/* Top Navigation */}
      <Navbar
        onOpenHotlinkTool={scrollToHotlinkTool}
        onOpenDeepDive={() => setIsDeepDiveOpen(true)}
      />

      <main>
        {/* Hero Section */}
        <div id="platform">
          <Hero
            onLaunchApp={handleLaunchApp}
            onOpenDeepDive={() => setIsDeepDiveOpen(true)}
          />
        </div>

        {/* Central Featured Image Display with Hotlink Overlay */}
        <FeaturedImageCard
          currentImage={currentImage}
          onOpenHotlinkTool={scrollToHotlinkTool}
        />

        {/* Hello Everyone Greeting Section */}
        <div id="solutions">
          <GreetingSection />
        </div>

        {/* Step 01 & Step 02 Feature Cards */}
        <StepCards />

        {/* Interactive Hotlink Generator Tool */}
        <HotlinkTool
          currentImage={currentImage}
          onSelectImage={(img) => setCurrentImage(img)}
        />
      </main>

      {/* Footer */}
      <Footer />

      {/* Interactive Project Deep Dive Overlay */}
      <DeepDiveModal
        isOpen={isDeepDiveOpen}
        onClose={() => setIsDeepDiveOpen(false)}
      />
    </div>
  );
}
