export interface HotlinkImage {
  id: string;
  title: string;
  url: string;
  alt: string;
  category: string;
  width?: number;
  height?: number;
  author?: string;
  description?: string;
}

export interface ProjectStep {
  id: string;
  stepNumber: string;
  title: string;
  content: string;
  iconName: string;
  tags: string[];
}

export interface TechSkill {
  name: string;
  level: number;
  category: 'frontend' | 'styling' | 'tools' | 'concept';
}
